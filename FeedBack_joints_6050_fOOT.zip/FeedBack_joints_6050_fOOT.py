import pybullet as p
import pybullet_data
import time
import numpy as np

# Connect to PyBullet
physicsClient = p.connect(p.GUI)

# Set up environment
p.setAdditionalSearchPath(pybullet_data.getDataPath())  # Add PyBullet data path
p.setGravity(0, 0, -9.8)

# Load plane and the uploaded robot URDF
planeId = p.loadURDF("plane.urdf")
robotId = p.loadURDF("MJKURDF.urdf", basePosition=[0, 0, 0.5])

# Extract link indices for feet from the URDF file
num_joints = p.getNumJoints(robotId)
link_indices = {"l_foot": None, "r_foot": None}
for i in range(num_joints):
    joint_info = p.getJointInfo(robotId, i)
    link_name = joint_info[12].decode('utf-8')  # Joint info's 12th element is the child link name
    if link_name in link_indices:
        link_indices[link_name] = i

# Ensure that both feet are detected
assert link_indices["l_foot"] is not None, "Left foot link not found in URDF!"
assert link_indices["r_foot"] is not None, "Right foot link not found in URDF!"

# Function to simulate pressure sensor data
def get_pressure_sensor_data(robot_id, link_index):
    """
    Simulate a pressure sensor on the given link.
    """
    contact_points = p.getContactPoints(bodyA=robot_id, linkIndexA=link_index)
    total_force = 0.0
    for contact in contact_points:
        total_force += contact[9]  # The 9th element is the normal force
    return total_force

# Function to simulate MPU6050 data from the pelvis link
def get_mpu6050_data(robot_id, link_index):
    # Get the link's orientation in world space
    _, orientation = p.getBasePositionAndOrientation(robot_id) if link_index == -1 else p.getLinkState(robot_id,
                                                                                                       link_index,
                                                                                                       computeForwardKinematics=True)[
                                                                                        :2]
    # Convert quaternion to Euler angles
    euler_orientation = p.getEulerFromQuaternion(orientation)  # (roll, pitch, yaw)
    return np.degrees(euler_orientation)  # Convert radians to degrees

# Function to get feedback of all joint states
def get_joint_feedback(robot_id):
    joint_data = []
    num_joints = p.getNumJoints(robot_id)
    for joint_index in range(num_joints):
        joint_info = p.getJointInfo(robot_id, joint_index)
        joint_name = joint_info[1].decode('utf-8')  # Get joint name
        joint_state = p.getJointState(robot_id, joint_index)  # Get joint state

        position = joint_state[0]  # Joint position (rad)
        velocity = joint_state[1]  # Joint velocity (rad/s)
        torque = joint_state[3]  # Joint torque (Nm)

        joint_data.append({
            "joint_name": joint_name,
            "position_deg": np.degrees(position),  # Convert position to degrees
            "velocity": velocity,
            "torque": torque
        })
    return joint_data

# Stabilize the robot by locking joints in initial positions
for joint_index in range(num_joints):
    p.setJointMotorControl2(robotId, joint_index, controlMode=p.POSITION_CONTROL, targetPosition=0.0)

# Simulation loop
while True:
    # Step simulation
    p.stepSimulation()

    # Get MPU6050 sensor data
    pelvis_link_index = -1  # Base link in PyBullet
    orientation = get_mpu6050_data(robotId, pelvis_link_index)
    print(
        f"MPU6050 Data (Pelvis Orientation): Roll: {orientation[0]:.2f}, Pitch: {orientation[1]:.2f}, Yaw: {orientation[2]:.2f}")

    # Get feedback from all joints
    joint_feedback = get_joint_feedback(robotId)
    for joint in joint_feedback:
        print(f"Joint: {joint['joint_name']}, Position: {joint['position_deg']:.2f} deg, "
              f"Velocity: {joint['velocity']:.2f} rad/s, Torque: {joint['torque']:.2f} Nm")

    # Get pressure sensor data for the feet
    left_foot_force = get_pressure_sensor_data(robotId, link_indices["l_foot"])
    right_foot_force = get_pressure_sensor_data(robotId, link_indices["r_foot"])
    print(f"Pressure Sensor Data: Left Foot: {left_foot_force:.2f} N, Right Foot: {right_foot_force:.2f} N")

    # Add your control logic here using orientation, joint feedback, and pressure data (e.g., gait control)

    time.sleep(1 / 240)

# Disconnect after exiting loop (if needed)
p.disconnect()
