import cv2
import pickle
import numpy as np
from deepface import DeepFace

# Load trained model
with open("trained_faces.pkl", "rb") as f:
    data = pickle.load(f)

known_face_encodings = data["encodings"]
known_face_names = data["names"]

# Open webcam
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    try:
        # Get ArcFace embedding of the current frame (first face only)
        embedding = DeepFace.represent(img_path=frame, model_name="ArcFace", enforce_detection=True)

        if embedding:
            face_embedding = np.array(embedding[0]["embedding"])

            # Compare with known faces using cosine similarity
            similarities = [np.dot(face_embedding, known_vec) / (np.linalg.norm(face_embedding) * np.linalg.norm(known_vec)) for known_vec in known_face_encodings]

            best_match_index = int(np.argmax(similarities))
            best_similarity = similarities[best_match_index]

            if best_similarity > 0.55:  # Tune this threshold
                name = known_face_names[best_match_index]
            else:
                name = "Unknown"

            # Draw label on frame
            cv2.putText(frame, f"{name} ({best_similarity:.2f})", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    except Exception as e:
        cv2.putText(frame, "No face detected", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    cv2.imshow("ArcFace Real-Time Recognition", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
