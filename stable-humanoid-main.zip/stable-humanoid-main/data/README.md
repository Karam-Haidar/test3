Store problems for benchmarking here
