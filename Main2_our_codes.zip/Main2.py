import pybullet as p
import pybullet_data
import time
import numpy as np
import math

# PID controller for balance
# pid = PID(1.0, 0.1, 0.05)  # Kp, Ki, Kd, adjust as needed

# Robot dimensions
thigh_length = 10  # cm
calf_length = 10  # cm
foot_length = 5  # cm
target_pitch = 0  # Target pitch angle for balance (horizontal)
max_step_height = thigh_length + calf_length - 2  # cm


# ZMP parameters
com_x, com_y, com_z = 0, 0, 47.7  # cm from the floor
stance_leg_length = 0.2  # meters
g = -9.81  # m/s^2
zmp_tolerance = 0.05 # Allowable ZMP deviation (meters)

# Connect to PyBullet
physicsClient = p.connect(p.GUI)
# p.resetSimulation()
# Set up environment
p.setAdditionalSearchPath(pybullet_data.getDataPath())  # Add PyBullet data path
p.setGravity(0, 0, -9.8)
# p.setRealTimeSimulation(0)


planeId = p.loadURDF("plane.urdf") #, [0, 0, 0], [0, 0, 0, 1])
robot_id = p.loadURDF("MJKURDF.urdf", basePosition=[0, 0, 0.5]) #, [0, 0, 0, 1], useFixedBase=False)


def get_joint_feedback (robot_id, joint_index, feedback_type):
    joint_state = p.getJointState(robot_id, joint_index)  # Get joint state
    if  feedback_type == "position":
        position =  np.degrees (joint_state[0])  # Joint position (converted from rad to degree)
        return position
    elif  feedback_type == "velocity":
            velocity = joint_state[1]  # Joint velocity (rad/s)
            return velocity
    elif  feedback_type == "torque":
            torque = joint_state[3]  # Joint torque (Nm)
            return torque
    return None


# Function to simulate pressure sensor data
def get_pressure_sensor_data(robot_id, link_index):
    """
    Simulate a pressure sensor on the given link.
    """
    contact_points = p.getContactPoints(bodyA=robot_id, linkIndexA=link_index)
    total_force = 0.0
    for contact in contact_points:
        total_force += contact[9]  # The 9th element is the normal force
    return total_force

def get_mpu6050_data(robot_id, link_index):
    # Get the link's orientation in world space
    _, orientation = p.getBasePositionAndOrientation(robot_id) if link_index == -1 else p.getLinkState(robot_id,link_index,computeForwardKinematics=True)[ :2]
    # Convert quaternion to Euler angles
    euler_orientation = p.getEulerFromQuaternion(orientation)  # (roll, pitch, yaw)
    return np.degrees(euler_orientation)  # Convert radians to degrees

def get_servo_angle(joint_index):  # def get_servo_angle(servo_id):
    """
    Reads the current angle of the servo motor using Feetech SCS115 feedback protocol.
    """
    # command = bytearray([servo_id, 0x02])  # Command to request current position
    # ser.write(command)
    # response = ser.read(6)  # Response is 6 bytes (protocol specific)


    joint_state = p.getJointState(robot_id, joint_index)  # Get joint state
    position = joint_state[0]  # Joint position (rad)
    position = np.degrees(position)  # Convert position to degrees
    angle = (position / 4096) * 360  # Convert position to angle
    return angle

def zmp_control(robot_id):

    com = p.getBasePositionAndOrientation(robot_id)[0]
    zmp_x, zmp_y = com[0], com[1]

    # Check if ZMP is within bounds
    if not (-zmp_tolerance <= zmp_x <= zmp_tolerance and -zmp_tolerance <= zmp_y <= zmp_tolerance):
         print("ZMP out of bounds! Adjusting...")
         adjustment = [0, 0, 0]

         # Adjust COM by moving hips/legs
         if zmp_x < -zmp_tolerance:
            adjustment[0] = 0.01 # Move forward
         elif zmp_x > zmp_tolerance:
            adjustment[0] = -0.01 # Move backward

         if zmp_y < -zmp_tolerance:
            adjustment[1] = 0.01 # Move left
         elif zmp_y > zmp_tolerance:
            adjustment[1] = -0.01 # Move right

         # Apply adjustment
         p.resetBasePositionAndOrientation(robot_id, [com[0] + adjustment[0], com[1] + adjustment[1], com[2]], p.getQuaternionFromEuler([0, 0, 0]))
         print(f"Adjusted COM: {com[0] + adjustment[0]}, {com[1] + adjustment[1]}")

def move_leg(robot_id, target_position, leg):

     hip_joint, knee_joint, ankle_joint = (2, 3, 4)  if leg == "right" else (7, 8, 9)


     hip_angle, knee_angle, ankle_angle = inverse_kinematics(target_position)
     print(f"hip= {hip_angle}\n, knee= {knee_angle}\n, ankle = {ankle_angle}\n")
     if hip_angle is None:
        return

     # Set joint positions using feedback from PyBullet
     p.setJointMotorControl2(robot_id, hip_joint, p.POSITION_CONTROL, targetPosition=hip_angle)
     p.setJointMotorControl2(robot_id, knee_joint, p.POSITION_CONTROL, targetPosition=knee_angle)
     p.setJointMotorControl2(robot_id, ankle_joint, p.POSITION_CONTROL, targetPosition=ankle_angle)
     zmp_control(robot_id)

# Move Leg
# def move_leg (robot_id, leg, step):
#     """
#      Moves the specified leg of the robot.
#      """
#     hip_joint, knee_joint, ankle_joint = (2, 3, 4) if leg == "right" else (7, 8, 9)
#     if leg == "right":
#         target_pos = [0.1, -0.05, 0.2] # Example target
#     else:
#         target_pos = [0.1, 0.05, 0.2]# Example target
#
#     # Apply target position to the robot's joints (simplified for illustration)
#     p.setJointMotorControl2(robot_id, 1, p.POSITION_CONTROL, targetPosition=target_pos[0])
#     p.setJointMotorControl2(robot_id, 2, p.POSITION_CONTROL, targetPosition=target_pos[1])
#     p.setJointMotorControl2(robot_id, 3, p.POSITION_CONTROL, targetPosition=target_pos[2])

# def inverse_kinematics(target_position):
#     """
#     Computes joint angles for the hip, knee, and ankle given the desired foot position.
#     """
#     x, y, z = target_position
#
#     # Calculate distance to the target
#     distance = math.sqrt(x**2 + z**2)
#
#     # Validate target position
#     if distance > (thigh_length + calf_length):
#         print(f"Target position {target_position} is out of reach.")
#         return None, None, None
#
#     # Knee angle using the cosine rule
#     knee_angle = math.acos((distance**2 - thigh_length**2 - calf_length**2) / (2 * thigh_length * calf_length))
#
#     # Hip angle
#     hip_angle = math.atan2(z, x) - math.atan2(calf_length * math.sin(knee_angle), thigh_length + calf_length * math.cos(knee_angle))
#
#     # Ankle angle to maintain foot orientation
#     ankle_angle = -hip_angle - knee_angle
#
#     return hip_angle, knee_angle, ankle_angle

def inverse_kinematics(target_position):
    """
    Calculates joint angles for hip, knee, and ankle.
    Incorporates joint limits and validates feasibility.
    """
    x, y, z = target_position
    distance = math.sqrt(x**2 + y**2 + z**2)

    # Validate target position
    if distance > (thigh_length + calf_length):
        print(f"Target out of reach: {target_position}")
        return None, None, None

     # Knee angle using cosine rule
    knee_angle = math.acos((distance**2 - thigh_length**2 - calf_length**2) / (2 * thigh_length * calf_length))

    # Hip angle using trigonometry
    hip_angle = math.atan2(y, x)

    # Ankle angle to maintain balance
    ankle_angle = math.atan2(z, math.sqrt(x**2 + y**2)) - knee_angle

    # Convert to degrees and validate joint limits
    hip_angle = max(-90, min(90, math.degrees(hip_angle)))
    knee_angle = max(-90, min(90, math.degrees(knee_angle)))
    ankle_angle = max(-90, min(90, math.degrees(ankle_angle)))

    return hip_angle, knee_angle, ankle_angle


def initialize_robot_motors(robot_id):
    # Stabilize the robot by locking joints in initial positions
    num_joints = p.getNumJoints(robot_id)
    for joint_index in range(num_joints):
        p.setJointMotorControl2(robot_id, joint_index, controlMode=p.POSITION_CONTROL, targetPosition=0.0)


# Walking Gait with Feedback
def walking_gait(robot_id):
     """
     Executes a walking gait using inverse kinematics for foot placement.
     """
     step_length = 0.1 # Meters
     step_height = 0.05 # Meters

     for step in range(10):
         # Step forward with the right leg
        print(f"Step {step + 1}: Moving Right Leg")
        target_position = [step_length, -0.05, step_height]
        move_leg(robot_id, target_position, "right")
        time.sleep(0.2)

        # Step forward with the left leg
        print(f"Step {step + 1}: Moving Left Leg")
        target_position = [step_length, 0.05, step_height]
        move_leg(robot_id, target_position, "left")
        time.sleep(0.2)


def simulate_robot():
    # plane_id = initialize_simulation()
    # robot_id = load_robot(urdf_path)
    initialize_robot_motors(robot_id)
    try:
        for _ in range(240 * 10): # Run for 20 seconds
            pelvis_link_index = -1  # Base link in PyBullet
            #orientation = get_mpu6050_data(robot_id, pelvis_link_index)
            #print(f"MPU6050 Data (Pelvis Orientation): Roll: {orientation[0]:.2f}, Pitch: {orientation[1]:.2f}, Yaw: {orientation[2]:.2f}")
            p.stepSimulation()
            walking_gait(robot_id)
            #zmp_control(robot_id)
            time.sleep(1/240)
    except KeyboardInterrupt:
        print("Simulation interrupted.")
    finally:
        p.disconnect()
simulate_robot()
# while True:
#     # Step simulation
#     p.stepSimulation()
#     pelvis_link_index = -1  # Base link in PyBullet
#     orientation = get_mpu6050_data(robot_id, pelvis_link_index)
#     print(f"MPU6050 Data (Pelvis Orientation): Roll: {orientation[0]:.2f}, Pitch: {orientation[1]:.2f}, Yaw: {orientation[2]:.2f}")
#
#     time.sleep(1/240)
# p.disconnect()